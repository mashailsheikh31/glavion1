document.addEventListener('DOMContentLoaded', () => {
  // Task 1: Login Form Handling
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();
      const errorElement = document.getElementById('login-error');

      if (!email || !password) {
        errorElement.textContent = 'Please enter both email and password.';
        errorElement.style.display = 'block';
      } else {
        errorElement.style.display = 'none';
        window.location.href = 'dashboard.html';
      }
    });
  }

  // Task 2 & 3: Check In / Check Out Logic
  const checkInBtn = document.getElementById('check-in-btn');
  const checkOutBtn = document.getElementById('check-out-btn');
  const statusDisplay = document.getElementById('attendance-status');
  const checkInTimeText = document.getElementById('check-in-time');
  const checkOutTimeText = document.getElementById('check-out-time');

  if (checkInBtn && checkOutBtn) {
    checkInBtn.addEventListener('click', () => {
      const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      statusDisplay.textContent = 'Present';
      statusDisplay.className = 'badge badge-present';
      checkInTimeText.textContent = currentTime;
      
      checkInBtn.disabled = true;
      checkOutBtn.disabled = false;
    });

    checkOutBtn.addEventListener('click', () => {
      const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      checkOutTimeText.textContent = currentTime;
      
      checkOutBtn.disabled = true;
    });
  }

  // Task 4: Mobile Sidebar Menu Toggle
  const menuToggle = document.getElementById('menu-toggle');
  const sidebar = document.querySelector('.sidebar');

  if (menuToggle && sidebar) {
    menuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });
  }
});